"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

type Tab = "home" | "learn" | "map" | "passport" | "profile";
type Props = { base: string; label: string; labels: Record<Tab, string> };

const tabs: { key: Tab; path: string; icon: string }[] = [
  { key: "home", path: "", icon: "M3 11l9-8 9 8v9a1 1 0 01-1 1h-5v-6H9v6H4a1 1 0 01-1-1z" },
  { key: "learn", path: "/learn", icon: "M4 5a2 2 0 012-2h12v16H6a2 2 0 00-2 2zM4 19a2 2 0 012-2h12" },
  { key: "map", path: "/map", icon: "M9 4l6 2 5-2v14l-5 2-6-2-5 2V6zM9 4v14M15 6v14" },
  { key: "passport", path: "/passport", icon: "M6 2h12a1 1 0 011 1v18a1 1 0 01-1 1H6a1 1 0 01-1-1V3a1 1 0 011-1zM12 8a3 3 0 100 6 3 3 0 000-6zM9 18h6" },
  { key: "profile", path: "/profile", icon: "M12 12a4 4 0 100-8 4 4 0 000 8zM4 21a8 8 0 0116 0" },
];

/** শুধু মোবাইলে (md-এর নিচে)। সক্রিয় ট্যাব রঙ + মোটা লেখা + aria-current দিয়ে বোঝানো হয়। */
export function BottomTabBar({ base, label, labels }: Props) {
  const pathname = usePathname();
  return (
    <nav aria-label={label} className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-surface md:hidden" style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)" }}>
      <ul className="grid grid-cols-5">
        {tabs.map(({ key, path, icon }) => {
          const href = `${base}${path}` || "/";
          const active = path === "" ? pathname === href : pathname.startsWith(href);
          return (
            <li key={key}>
              <Link href={href} aria-current={active ? "page" : undefined}
                    className={`flex min-h-14 flex-col items-center justify-center gap-0.5 text-xs ${active ? "font-bold text-primary" : "text-muted"}`}>
                <svg aria-hidden width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={active ? 2.4 : 1.8} strokeLinecap="round" strokeLinejoin="round"><path d={icon} /></svg>
                {labels[key]}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
