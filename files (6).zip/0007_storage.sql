-- 0007: মিডিয়া Storage বাকেট
-- ছবি পাবলিক পড়া যায়; আপলোড/মোছা শুধু admin ও editor। ৫ MB সীমা, শুধু নির্দিষ্ট ছবির ধরন।
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('media', 'media', true, 5242880, array['image/jpeg','image/png','image/webp','image/svg+xml'])
on conflict (id) do update set public = excluded.public,
  file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

create policy "media_public_read"  on storage.objects for select using (bucket_id = 'media');
create policy "media_staff_insert" on storage.objects for insert to authenticated with check (bucket_id = 'media' and public.is_staff());
create policy "media_staff_update" on storage.objects for update to authenticated using (bucket_id = 'media' and public.is_staff());
create policy "media_staff_delete" on storage.objects for delete to authenticated using (bucket_id = 'media' and public.is_staff());
