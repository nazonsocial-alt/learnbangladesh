"use client";
import { createContext, useCallback, useContext, useRef, useState, ReactNode } from "react";

type Tone = "success" | "error" | "info";
type Item = { id: number; message: string; tone: Tone };
const Ctx = createContext<(message: string, tone?: Tone) => void>(() => {});
export const useToast = () => useContext(Ctx);

export function ToastProvider({ children, dismissLabel }: { children: ReactNode; dismissLabel: string }) {
  const [items, setItems] = useState<Item[]>([]);
  const next = useRef(0);
  const remove = (id: number) => setItems((l) => l.filter((i) => i.id !== id));
  const push = useCallback((message: string, tone: Tone = "info") => {
    const id = ++next.current;
    setItems((l) => [...l.slice(-2), { id, message, tone }]);
    setTimeout(() => remove(id), 6000);
  }, []);
  const icon = { success: "✓", error: "!", info: "i" } as const;
  return (
    <Ctx.Provider value={push}>
      {children}
      {/* স্ক্রিন রিডারে বার্তা ঘোষিত হয়; নিচের ট্যাব বারের উপরে বসে */}
      <div role="status" aria-live="polite" className="pointer-events-none fixed inset-x-0 bottom-20 z-50 flex flex-col items-center gap-2 px-4 md:bottom-6">
        {items.map((t) => (
          <div key={t.id} className="pointer-events-auto flex max-w-md items-center gap-3 rounded-md border border-border bg-surface px-4 py-3 shadow-md">
            <span aria-hidden className={`grid h-6 w-6 place-items-center rounded-full text-sm font-bold ${t.tone === "error" ? "bg-danger text-white" : "bg-primary text-primary-on"}`}>{icon[t.tone]}</span>
            <span className="flex-1">{t.message}</span>
            <button onClick={() => remove(t.id)} aria-label={dismissLabel} className="min-h-11 min-w-11 rounded-md hover:bg-surface-2">×</button>
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}
