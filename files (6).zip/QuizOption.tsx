export type OptionState = "idle" | "correct" | "wrong" | "missed";
type Props = {
  name: string; value: string; text: string; checked: boolean; disabled?: boolean;
  state?: OptionState; onSelect: (value: string) => void;
  labels: { correct: string; wrong: string; missed: string };
};

/** নেটিভ radio ব্যবহার করা হয়েছে, তাই কিবোর্ড (তীর চিহ্ন) ও স্ক্রিন রিডার বিনামূল্যে কাজ করে।
 *  উত্তরের ফল রঙ + আইকন + লেখা, তিনভাবেই দেখানো হয়। */
export function QuizOption({ name, value, text, checked, disabled, state = "idle", onSelect, labels }: Props) {
  const tone =
    state === "correct" ? "border-primary bg-primary-soft"
    : state === "wrong" ? "border-danger"
    : state === "missed" ? "border-primary border-dashed"
    : checked ? "border-primary bg-primary-soft" : "border-border hover:bg-surface-2";
  const mark = state === "correct" ? "✓" : state === "wrong" ? "✗" : state === "missed" ? "✓" : "";
  const note = state === "correct" ? labels.correct : state === "wrong" ? labels.wrong : state === "missed" ? labels.missed : "";
  return (
    <label className={`flex min-h-12 cursor-pointer items-center gap-3 rounded-md border-2 px-4 py-3 has-[:focus-visible]:outline has-[:focus-visible]:outline-[3px] has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-[var(--focus)] ${tone} ${disabled ? "cursor-default" : ""}`}>
      <input type="radio" className="sr-only" name={name} value={value} checked={checked} disabled={disabled} onChange={() => onSelect(value)} />
      <span aria-hidden className={`grid h-6 w-6 shrink-0 place-items-center rounded-full border-2 text-sm font-bold ${checked || state !== "idle" ? "border-primary" : "border-border"}`}>{mark}</span>
      <span className="flex-1">{text}</span>
      {note ? <span className="text-sm font-medium">{note}</span> : null}
    </label>
  );
}
