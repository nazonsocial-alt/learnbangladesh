import Image from "next/image";
import Link from "next/link";
import { ReactNode } from "react";

type NavItem = { href: string; label: string };
type Props = { homeHref: string; homeLabel: string; nav: NavItem[]; navLabel: string; searchHref: string; searchLabel: string; actions: ReactNode };

export function Header({ homeHref, homeLabel, nav, navLabel, searchHref, searchLabel, actions }: Props) {
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-bg/90 backdrop-blur" style={{ paddingTop: "env(safe-area-inset-top, 0px)" }}>
      <div className="mx-auto flex h-16 max-w-6xl items-center gap-4 px-4">
        <Link href={homeHref} aria-label={homeLabel} className="flex items-center">
          <Image src="/brand/logo.png" alt="" width={44} height={44} priority className="rounded-md" />
        </Link>
        <nav aria-label={navLabel} className="hidden flex-1 md:block">
          <ul className="flex gap-1">
            {nav.map((n) => (
              <li key={n.href}><Link href={n.href} className="grid min-h-11 place-items-center rounded-md px-3 font-medium hover:bg-surface-2">{n.label}</Link></li>
            ))}
          </ul>
        </nav>
        <div className="ml-auto flex items-center gap-1">
          <Link href={searchHref} aria-label={searchLabel} className="grid min-h-11 min-w-11 place-items-center rounded-md hover:bg-surface-2"><span aria-hidden>🔍</span></Link>
          {actions}
        </div>
      </div>
    </header>
  );
}
