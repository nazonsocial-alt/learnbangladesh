"use client";
import { useCallback, useEffect, useState } from "react";

export type Prefs = {
  theme?: "light" | "dark";
  contrast?: "high";
  font?: "lg" | "xl";
  motion?: "off";
};
const KEY = "lb-prefs";

/** <head>-এ বসান: পেজ আঁকার আগেই থিম সেট হয়, তাই সাদা ঝলক (flash) হয় না। স্ট্যাটিক স্ট্রিং, ব্যবহারকারীর ইনপুট নেই। */
export function ThemeScript() {
  const code = `(function(){try{var p=JSON.parse(localStorage.getItem('${KEY}')||'{}');var r=document.documentElement;r.dataset.theme=p.theme||(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');if(p.contrast)r.dataset.contrast=p.contrast;if(p.font)r.dataset.font=p.font;if(p.motion)r.dataset.motion=p.motion;}catch(e){}})();`;
  return <script dangerouslySetInnerHTML={{ __html: code }} />;
}

function apply(p: Prefs) {
  const r = document.documentElement;
  const set = (k: string, v?: string) => (v ? (r.dataset[k] = v) : delete r.dataset[k]);
  if (p.theme) r.dataset.theme = p.theme;
  set("contrast", p.contrast); set("font", p.font); set("motion", p.motion);
}

export function usePrefs() {
  const [prefs, setPrefs] = useState<Prefs>({});
  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(KEY) || "{}") as Prefs;
      const theme = saved.theme ?? (document.documentElement.dataset.theme as Prefs["theme"]);
      setPrefs({ ...saved, theme });
    } catch { /* স্টোরেজ বন্ধ থাকলেও অ্যাপ চলবে */ }
  }, []);
  const update = useCallback((patch: Prefs) => {
    setPrefs((cur) => {
      const next = { ...cur, ...patch };
      apply(next);
      try { localStorage.setItem(KEY, JSON.stringify(next)); } catch { /* উপেক্ষা */ }
      return next;
    });
  }, []);
  return { prefs, update };
}
