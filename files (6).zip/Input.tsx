import { InputHTMLAttributes, forwardRef, useId } from "react";

type Props = InputHTMLAttributes<HTMLInputElement> & { label: string; hint?: string; error?: string };

/** লেবেল সবসময় দেখা যায় (placeholder নয়)। ত্রুটি বার্তা স্ক্রিন রিডারে ঘোষিত হয়। */
export const Input = forwardRef<HTMLInputElement, Props>(function Input(
  { label, hint, error, className = "", id, ...rest }, ref
) {
  const auto = useId();
  const inputId = id ?? auto;
  const hintId = hint ? `${inputId}-hint` : undefined;
  const errId = error ? `${inputId}-err` : undefined;
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={inputId} className="font-medium">{label}</label>
      <input
        ref={ref} id={inputId}
        aria-invalid={error ? true : undefined}
        aria-describedby={[hintId, errId].filter(Boolean).join(" ") || undefined}
        className={`min-h-11 rounded-md border bg-surface px-4 text-text placeholder:text-muted ${error ? "border-danger" : "border-border"} ${className}`}
        {...rest}
      />
      {hint && !error ? <p id={hintId} className="text-sm text-muted">{hint}</p> : null}
      {error ? <p id={errId} role="alert" className="text-sm font-medium text-danger">{error}</p> : null}
    </div>
  );
});
