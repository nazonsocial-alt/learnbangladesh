-- Learn Bangladesh — 0001: extensions ও enum টাইপ
create extension if not exists pgcrypto;

create type content_status as enum ('draft', 'reviewed', 'published', 'archived');
create type app_role       as enum ('admin', 'editor', 'reviewer');
create type section_kind   as enum ('overview', 'history', 'culture', 'food', 'attractions', 'economy', 'facts');
create type media_kind     as enum ('image', 'video', 'illustration');
create type media_license  as enum ('public_domain', 'cc0', 'cc_by', 'cc_by_sa', 'gov_reuse', 'original', 'user_uploaded');
create type question_type  as enum ('mcq', 'true_false', 'image', 'map');
create type difficulty     as enum ('easy', 'medium', 'hard');
create type progress_state as enum ('in_progress', 'completed');
create type goal_period    as enum ('weekly', 'monthly');
create type daily_kind     as enum ('lesson', 'quiz', 'district', 'food', 'person');
