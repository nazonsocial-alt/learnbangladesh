-- 0005: Row Level Security — প্রতিটি টেবিলে চালু

do $$
declare t text;
begin
  for t in select tablename from pg_tables where schemaname = 'public' loop
    execute format('alter table %I enable row level security', t);
  end loop;
end $$;

-- প্রকাশিত কনটেন্ট সবাই পড়বে; লিখতে পারবে শুধু admin/editor
do $$
declare t text;
begin
  foreach t in array array['districts','district_sections','lessons','learning_paths','people','foods','heritage_sites','history_events','media_items','quizzes'] loop
    execute format('create policy "public_read_published" on %I for select using (status = ''published'')', t);
    execute format('create policy "staff_read_all" on %I for select to authenticated using (is_staff() or has_role(''reviewer''))', t);
    execute format('create policy "staff_write" on %I for all to authenticated using (is_staff()) with check (is_staff())', t);
  end loop;
  foreach t in array array['divisions','district_neighbors','sources','content_sources','daily_features','badges','achievements'] loop
    execute format('create policy "public_read" on %I for select using (true)', t);
    execute format('create policy "staff_write" on %I for all to authenticated using (is_staff()) with check (is_staff())', t);
  end loop;
end $$;

-- রিভিউয়ার শুধু status ও reviewed_by বদলাতে পারবে (সম্পূর্ণ লেখার অধিকার নেই)
create policy "reviewer_update_districts" on districts for update to authenticated using (has_role('reviewer')) with check (has_role('reviewer'));
create policy "reviewer_update_lessons"   on lessons   for update to authenticated using (has_role('reviewer')) with check (has_role('reviewer'));

-- প্রশ্ন ও অপশন: প্রকাশিত কুইজের হলে পড়া যাবে। সঠিক উত্তর (question_answers) ক্লায়েন্টে কোনো পলিসি নেই
create policy "questions_read" on questions for select using (exists (select 1 from quizzes q where q.id = quiz_id and q.status = 'published'));
create policy "questions_staff" on questions for all to authenticated using (is_staff()) with check (is_staff());
create policy "options_read" on question_options for select using (exists (select 1 from questions qu join quizzes q on q.id = qu.quiz_id where qu.id = question_id and q.status = 'published'));
create policy "options_staff" on question_options for all to authenticated using (is_staff()) with check (is_staff());
create policy "answers_staff" on question_answers for all to authenticated using (is_staff()) with check (is_staff());

-- নিজের ডেটা
create policy "own_profile_read"   on profiles for select to authenticated using (id = auth.uid());
create policy "own_profile_update" on profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy "own_roles_read"     on user_roles for select to authenticated using (user_id = auth.uid() or has_role('admin'));
create policy "admin_roles_write"  on user_roles for all to authenticated using (has_role('admin')) with check (has_role('admin'));
create policy "admin_profiles_read" on profiles for select to authenticated using (has_role('admin'));

-- অগ্রগতি/XP/ব্যাজ/সার্টিফিকেট: শুধু পড়া। লেখা হয় সুরক্ষিত ফাংশন বা সার্ভার (service role) দিয়ে
do $$
declare t text;
begin
  foreach t in array array['quiz_attempts','lesson_progress','district_progress','xp_events','streaks','user_badges','user_achievements','certificates'] loop
    execute format('create policy "own_read" on %I for select to authenticated using (user_id = auth.uid())', t);
  end loop;
  foreach t in array array['bookmarks','goals'] loop
    execute format('create policy "own_all" on %I for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid())', t);
  end loop;
end $$;

create policy "own_notifications_read"   on notifications for select to authenticated using (user_id = auth.uid());
create policy "own_notifications_update" on notifications for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "admin_audit_read" on audit_log for select to authenticated using (has_role('admin'));
