-- 0004: ফাংশন ও ট্রিগার (সব গেমিফিকেশন লজিক সার্ভারে, ক্লায়েন্টে নয়)

create function today_dhaka() returns date language sql stable as
$$ select (now() at time zone 'Asia/Dhaka')::date $$;

create function has_role(r app_role) returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from user_roles where user_id = auth.uid() and role = r) $$;

create function is_staff() returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from user_roles where user_id = auth.uid() and role in ('admin','editor')) $$;

create function level_for_xp(xp bigint) returns int language sql immutable as
$$ select floor(sqrt(greatest(xp, 0) / 50.0))::int + 1 $$;

create function touch_updated_at() returns trigger language plpgsql as
$$ begin new.updated_at = now(); return new; end $$;

create trigger profiles_touch before update on profiles for each row execute function touch_updated_at();
create trigger districts_touch before update on districts for each row execute function touch_updated_at();
create trigger lessons_touch  before update on lessons  for each row execute function touch_updated_at();
create trigger sections_touch before update on district_sections for each row execute function touch_updated_at();

-- নতুন ব্যবহারকারীর জন্য প্রোফাইল
create function handle_new_user() returns trigger language plpgsql security definer set search_path = public as
$$
begin
  insert into profiles (id, display_name, avatar_url)
  values (new.id,
          coalesce(nullif(left(new.raw_user_meta_data->>'full_name', 60), ''), 'শিক্ষার্থী'),
          new.raw_user_meta_data->>'avatar_url');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

-- প্রতিটি জেলার জন্য একটি ডিফল্ট ব্যাজ (নাম অ্যাডমিন থেকে বদলানো যাবে)
create function create_district_badge() returns trigger language plpgsql as
$$
begin
  insert into badges (district_id, slug, name_bn) values (new.id, 'district-' || new.slug, new.name_bn || ' এক্সপ্লোরার');
  return new;
end $$;
create trigger districts_badge after insert on districts for each row execute function create_district_badge();

-- প্রকাশের শর্ত: রিভিউয়ার, ৭টি প্রকাশিত অংশ, কমপক্ষে ২টি সূত্র, ১০+ প্রশ্নের প্রকাশিত কুইজ
create function enforce_district_publish() returns trigger language plpgsql as
$$
declare sections int; sources_n int; questions_n int;
begin
  if new.status = 'published' and (tg_op = 'INSERT' or old.status is distinct from 'published') then
    if new.reviewed_by is null then raise exception 'প্রকাশের আগে রিভিউয়ার নির্ধারণ করতে হবে'; end if;
    select count(*) into sections from district_sections where district_id = new.id and status = 'published';
    if sections < array_length(enum_range(null::section_kind), 1) then
      raise exception 'সবগুলো অংশ প্রকাশিত নয় (% টি আছে)', sections; end if;
    select count(*) into sources_n from content_sources where entity_type = 'district' and entity_id = new.id;
    if sources_n < 2 then raise exception 'কমপক্ষে ২টি সূত্র দিতে হবে'; end if;
    select count(*) into questions_n from questions qu join quizzes q on q.id = qu.quiz_id
      where q.district_id = new.id and q.status = 'published';
    if questions_n < 10 then raise exception 'প্রকাশিত কুইজে কমপক্ষে ১০টি প্রশ্ন লাগবে'; end if;
    new.published_at = coalesce(new.published_at, now());
  end if;
  return new;
end $$;
create trigger districts_publish_guard before insert or update on districts for each row execute function enforce_district_publish();

create function enforce_lesson_publish() returns trigger language plpgsql as
$$
begin
  if new.status = 'published' and (tg_op = 'INSERT' or old.status is distinct from 'published') then
    if new.reviewed_by is null then raise exception 'প্রকাশের আগে রিভিউয়ার নির্ধারণ করতে হবে'; end if;
    if tg_op = 'INSERT' or not exists (select 1 from content_sources where entity_type = 'lesson' and entity_id = new.id) then
      raise exception 'কমপক্ষে ১টি সূত্র দিতে হবে'; end if;
    new.published_at = coalesce(new.published_at, now());
  end if;
  return new;
end $$;
create trigger lessons_publish_guard before insert or update on lessons for each row execute function enforce_lesson_publish();

-- অডিট লগ
create function audit_row() returns trigger language plpgsql security definer set search_path = public as
$$
begin
  insert into audit_log (actor, table_name, row_id, action)
  values (auth.uid(), tg_table_name, coalesce((to_jsonb(new)->>'id'), (to_jsonb(old)->>'id')), tg_op);
  return null;
end $$;
create trigger audit_districts after insert or update or delete on districts for each row execute function audit_row();
create trigger audit_lessons   after insert or update or delete on lessons   for each row execute function audit_row();
create trigger audit_media     after insert or update or delete on media_items for each row execute function audit_row();
create trigger audit_roles     after insert or update or delete on user_roles  for each row execute function audit_row();

-- স্ট্রিক
create function touch_streak(p_user uuid) returns void language plpgsql security definer set search_path = public as
$$
declare t date := today_dhaka();
begin
  insert into streaks (user_id, current_days, longest_days, last_active) values (p_user, 1, 1, t)
  on conflict (user_id) do update set
    current_days = case when streaks.last_active = t then streaks.current_days
                        when streaks.last_active = t - 1 then streaks.current_days + 1 else 1 end,
    longest_days = greatest(streaks.longest_days,
                   case when streaks.last_active = t then streaks.current_days
                        when streaks.last_active = t - 1 then streaks.current_days + 1 else 1 end),
    last_active = t;
end $$;

-- পাঠ সম্পন্ন
create function complete_lesson(p_lesson uuid) returns int language plpgsql security definer set search_path = public as
$$
declare uid uuid := auth.uid(); xp int;
begin
  if uid is null then raise exception 'লগইন প্রয়োজন'; end if;
  select xp_reward into xp from lessons where id = p_lesson and status = 'published';
  if xp is null then raise exception 'পাঠটি পাওয়া যায়নি'; end if;
  insert into lesson_progress (user_id, lesson_id) values (uid, p_lesson) on conflict do nothing;
  if found then
    insert into xp_events (user_id, amount, reason, ref_id) values (uid, xp, 'lesson', p_lesson) on conflict do nothing;
  end if;
  perform touch_streak(uid);
  return xp;
end $$;

-- জেলার অংশ পড়া
create function mark_section_read(p_district uuid, p_kind section_kind) returns void language plpgsql security definer set search_path = public as
$$
declare uid uuid := auth.uid();
begin
  if uid is null then raise exception 'লগইন প্রয়োজন'; end if;
  if not exists (select 1 from districts where id = p_district and status = 'published') then
    raise exception 'জেলাটি পাওয়া যায়নি'; end if;
  insert into district_progress (user_id, district_id, sections_read) values (uid, p_district, array[p_kind])
  on conflict (user_id, district_id) do update set sections_read =
    case when p_kind = any (district_progress.sections_read) then district_progress.sections_read
         else array_append(district_progress.sections_read, p_kind) end;
  perform touch_streak(uid);
end $$;

-- জেলা সম্পন্ন: সব অংশ পড়া + কুইজে পাস → স্ট্যাম্প, XP, ব্যাজ
create function complete_district(p_district uuid) returns int language plpgsql security definer set search_path = public as
$$
declare uid uuid := auth.uid(); d districts%rowtype; prog district_progress%rowtype;
begin
  if uid is null then raise exception 'লগইন প্রয়োজন'; end if;
  select * into d from districts where id = p_district and status = 'published';
  if not found then raise exception 'জেলাটি পাওয়া যায়নি'; end if;
  select * into prog from district_progress where user_id = uid and district_id = p_district;
  if not found or cardinality(prog.sections_read) < array_length(enum_range(null::section_kind), 1) then
    raise exception 'আগে সবগুলো অংশ পড়ুন'; end if;
  if not exists (select 1 from quiz_attempts a join quizzes q on q.id = a.quiz_id
                 where a.user_id = uid and q.district_id = p_district and a.passed) then
    raise exception 'আগে কুইজে পাস করুন'; end if;
  if prog.status = 'completed' then return prog.xp_awarded; end if;

  update district_progress set status = 'completed', completed_at = now(), xp_awarded = d.xp_reward
   where user_id = uid and district_id = p_district;
  insert into xp_events (user_id, amount, reason, ref_id) values (uid, d.xp_reward, 'district', p_district) on conflict do nothing;
  insert into user_badges (user_id, badge_id) select uid, id from badges where district_id = p_district on conflict do nothing;
  perform touch_streak(uid);
  return d.xp_reward;
end $$;

-- সার্টিফিকেট: প্রকাশিত সব জেলা (৬৪টি) সম্পন্ন হলেই
create function issue_certificate() returns text language plpgsql security definer set search_path = public as
$$
declare uid uuid := auth.uid(); published_n int; done_n int; num text; nm text;
begin
  if uid is null then raise exception 'লগইন প্রয়োজন'; end if;
  select number into num from certificates where user_id = uid;
  if num is not null then return num; end if;
  select count(*) into published_n from districts where status = 'published';
  if published_n < 64 then raise exception 'সবগুলো জেলার কনটেন্ট এখনও প্রকাশিত হয়নি'; end if;
  select count(*) into done_n from district_progress p join districts d on d.id = p.district_id
   where p.user_id = uid and p.status = 'completed' and d.status = 'published';
  if done_n < published_n then raise exception 'এখনও % টি জেলা বাকি', published_n - done_n; end if;
  select display_name into nm from profiles where id = uid;
  num := 'LB-' || to_char(now(), 'YYYY') || '-' || upper(encode(gen_random_bytes(5), 'hex'));
  insert into certificates (user_id, number, holder_name) values (uid, num, nm);
  return num;
end $$;

-- সার্টিফিকেট যাচাই (QR পেজ): কোনো ব্যক্তিগত তথ্য নয়, শুধু নাম ও তারিখ
create function verify_certificate(p_number text)
returns table (holder_name text, issued_at timestamptz) language sql stable security definer set search_path = public as
$$ select holder_name, issued_at from certificates where number = upper(trim(p_number)) $$;

-- লিডারবোর্ড (শুধু যারা অপ্ট-ইন করেছেন)
create function leaderboard(p_period text default 'week', p_limit int default 50)
returns table (rank_no bigint, display_name text, avatar_url text, xp bigint) language sql stable security definer set search_path = public as
$$
  select row_number() over (order by sum(x.amount) desc), p.display_name, p.avatar_url, sum(x.amount)::bigint
    from xp_events x join profiles p on p.id = x.user_id
   where p.show_on_leaderboard
     and x.created_at >= case p_period when 'week' then date_trunc('week', now())
                                       when 'month' then date_trunc('month', now())
                                       else '-infinity'::timestamptz end
   group by p.id, p.display_name, p.avatar_url
   order by 4 desc
   limit least(greatest(p_limit, 1), 100)
$$;

-- অনুমতি: ডিফল্টে সবার জন্য বন্ধ, প্রয়োজনমতো খোলা
revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function today_dhaka(), level_for_xp(bigint) to anon, authenticated;
grant execute on function has_role(app_role), is_staff() to authenticated;
grant execute on function complete_lesson(uuid), mark_section_read(uuid, section_kind),
                          complete_district(uuid), issue_certificate() to authenticated;
grant execute on function verify_certificate(text), leaderboard(text, int) to anon, authenticated;
