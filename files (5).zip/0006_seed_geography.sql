-- 0006: ৮ বিভাগ ও ৬৪ জেলার কাঠামো (ভৌগোলিক রেফারেন্স ডেটা)
-- সব জেলা 'draft' হিসেবে ঢোকে। কনটেন্ট রিভিউ ও প্রকাশের নিয়ম পূরণ না হওয়া পর্যন্ত সাইটে দেখা যাবে না।

insert into divisions (slug, name_bn, name_en, sort_order) values
 ('sylhet','সিলেট','Sylhet',1), ('barishal','বরিশাল','Barishal',2), ('mymensingh','ময়মনসিংহ','Mymensingh',3),
 ('rangpur','রংপুর','Rangpur',4), ('rajshahi','রাজশাহী','Rajshahi',5), ('khulna','খুলনা','Khulna',6),
 ('chattogram','চট্টগ্রাম','Chattogram',7), ('dhaka','ঢাকা','Dhaka',8);

insert into districts (division_id, slug, name_bn, name_en, sort_order)
select v.id, d.slug, d.bn, d.en, d.ord
from (values
 ('sylhet','sylhet','সিলেট','Sylhet',1), ('sylhet','moulvibazar','মৌলভীবাজার','Moulvibazar',2),
 ('sylhet','habiganj','হবিগঞ্জ','Habiganj',3), ('sylhet','sunamganj','সুনামগঞ্জ','Sunamganj',4),
 ('barishal','barishal','বরিশাল','Barishal',5), ('barishal','barguna','বরগুনা','Barguna',6),
 ('barishal','bhola','ভোলা','Bhola',7), ('barishal','jhalokati','ঝালকাঠি','Jhalokati',8),
 ('barishal','patuakhali','পটুয়াখালী','Patuakhali',9), ('barishal','pirojpur','পিরোজপুর','Pirojpur',10),
 ('mymensingh','mymensingh','ময়মনসিংহ','Mymensingh',11), ('mymensingh','jamalpur','জামালপুর','Jamalpur',12),
 ('mymensingh','netrokona','নেত্রকোনা','Netrokona',13), ('mymensingh','sherpur','শেরপুর','Sherpur',14),
 ('rangpur','rangpur','রংপুর','Rangpur',15), ('rangpur','dinajpur','দিনাজপুর','Dinajpur',16),
 ('rangpur','gaibandha','গাইবান্ধা','Gaibandha',17), ('rangpur','kurigram','কুড়িগ্রাম','Kurigram',18),
 ('rangpur','lalmonirhat','লালমনিরহাট','Lalmonirhat',19), ('rangpur','nilphamari','নীলফামারী','Nilphamari',20),
 ('rangpur','panchagarh','পঞ্চগড়','Panchagarh',21), ('rangpur','thakurgaon','ঠাকুরগাঁও','Thakurgaon',22),
 ('rajshahi','rajshahi','রাজশাহী','Rajshahi',23), ('rajshahi','bogura','বগুড়া','Bogura',24),
 ('rajshahi','joypurhat','জয়পুরহাট','Joypurhat',25), ('rajshahi','naogaon','নওগাঁ','Naogaon',26),
 ('rajshahi','natore','নাটোর','Natore',27), ('rajshahi','chapainawabganj','চাঁপাইনবাবগঞ্জ','Chapainawabganj',28),
 ('rajshahi','pabna','পাবনা','Pabna',29), ('rajshahi','sirajganj','সিরাজগঞ্জ','Sirajganj',30),
 ('khulna','khulna','খুলনা','Khulna',31), ('khulna','bagerhat','বাগেরহাট','Bagerhat',32),
 ('khulna','chuadanga','চুয়াডাঙ্গা','Chuadanga',33), ('khulna','jashore','যশোর','Jashore',34),
 ('khulna','jhenaidah','ঝিনাইদহ','Jhenaidah',35), ('khulna','kushtia','কুষ্টিয়া','Kushtia',36),
 ('khulna','magura','মাগুরা','Magura',37), ('khulna','meherpur','মেহেরপুর','Meherpur',38),
 ('khulna','narail','নড়াইল','Narail',39), ('khulna','satkhira','সাতক্ষীরা','Satkhira',40),
 ('chattogram','chattogram','চট্টগ্রাম','Chattogram',41), ('chattogram','coxs-bazar','কক্সবাজার','Cox''s Bazar',42),
 ('chattogram','bandarban','বান্দরবান','Bandarban',43), ('chattogram','rangamati','রাঙামাটি','Rangamati',44),
 ('chattogram','khagrachhari','খাগড়াছড়ি','Khagrachhari',45), ('chattogram','cumilla','কুমিল্লা','Cumilla',46),
 ('chattogram','brahmanbaria','ব্রাহ্মণবাড়িয়া','Brahmanbaria',47), ('chattogram','chandpur','চাঁদপুর','Chandpur',48),
 ('chattogram','feni','ফেনী','Feni',49), ('chattogram','lakshmipur','লক্ষ্মীপুর','Lakshmipur',50),
 ('chattogram','noakhali','নোয়াখালী','Noakhali',51),
 ('dhaka','dhaka','ঢাকা','Dhaka',52), ('dhaka','gazipur','গাজীপুর','Gazipur',53),
 ('dhaka','narayanganj','নারায়ণগঞ্জ','Narayanganj',54), ('dhaka','narsingdi','নরসিংদী','Narsingdi',55),
 ('dhaka','manikganj','মানিকগঞ্জ','Manikganj',56), ('dhaka','munshiganj','মুন্সীগঞ্জ','Munshiganj',57),
 ('dhaka','tangail','টাঙ্গাইল','Tangail',58), ('dhaka','kishoreganj','কিশোরগঞ্জ','Kishoreganj',59),
 ('dhaka','faridpur','ফরিদপুর','Faridpur',60), ('dhaka','gopalganj','গোপালগঞ্জ','Gopalganj',61),
 ('dhaka','madaripur','মাদারীপুর','Madaripur',62), ('dhaka','rajbari','রাজবাড়ী','Rajbari',63),
 ('dhaka','shariatpur','শরীয়তপুর','Shariatpur',64)
) as d(div, slug, bn, en, ord)
join divisions v on v.slug = d.div;

-- যাচাই: ৮ বিভাগ ও ৬৪ জেলা না হলে মাইগ্রেশন ব্যর্থ হবে
do $$
begin
  if (select count(*) from divisions) <> 8 then raise exception 'বিভাগ ৮টি হওয়ার কথা'; end if;
  if (select count(*) from districts) <> 64 then raise exception 'জেলা ৬৪টি হওয়ার কথা'; end if;
end $$;
