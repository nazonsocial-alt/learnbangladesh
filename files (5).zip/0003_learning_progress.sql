-- 0003: কুইজ, অগ্রগতি, গেমিফিকেশন

create table quizzes (
  id uuid primary key default gen_random_uuid(),
  district_id uuid references districts(id) on delete cascade,
  lesson_id uuid references lessons(id) on delete cascade,
  title_bn text not null, title_en text,
  difficulty difficulty not null default 'medium',
  time_limit_seconds int check (time_limit_seconds is null or time_limit_seconds > 0),
  pass_percent int not null default 70 check (pass_percent between 1 and 100),
  status content_status not null default 'draft',
  created_at timestamptz not null default now()
);
create unique index quizzes_one_per_district on quizzes(district_id) where district_id is not null;

create table questions (
  id uuid primary key default gen_random_uuid(),
  quiz_id uuid not null references quizzes(id) on delete cascade,
  type question_type not null default 'mcq',
  prompt_bn text not null, prompt_en text,
  image_media_id uuid references media_items(id) on delete set null,
  difficulty difficulty not null default 'medium',
  sort_order int not null default 0
);
create index questions_quiz_idx on questions(quiz_id, sort_order);

create table question_options (          -- সঠিক উত্তর এখানে নেই: ক্লায়েন্টে ফাঁস হবে না
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null references questions(id) on delete cascade,
  text_bn text not null, text_en text,
  sort_order int not null default 0
);
create index question_options_q_idx on question_options(question_id);

create table question_answers (          -- শুধু সার্ভার (service role) পড়তে পারে
  question_id uuid primary key references questions(id) on delete cascade,
  correct_option_id uuid not null references question_options(id) on delete cascade,
  explanation_bn text not null, explanation_en text
);

create table quiz_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  quiz_id uuid not null references quizzes(id) on delete cascade,
  score_percent int not null check (score_percent between 0 and 100),
  passed boolean not null,
  answers jsonb not null default '[]',
  started_at timestamptz not null default now(),
  finished_at timestamptz not null default now()
);
create index quiz_attempts_user_idx on quiz_attempts(user_id, quiz_id);

create table lesson_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  lesson_id uuid not null references lessons(id) on delete cascade,
  completed_at timestamptz not null default now(),
  primary key (user_id, lesson_id)
);

create table district_progress (         -- পাসপোর্ট: স্ট্যাটাস, সম্পন্নের তারিখ, XP
  user_id uuid not null references auth.users(id) on delete cascade,
  district_id uuid not null references districts(id) on delete cascade,
  sections_read section_kind[] not null default '{}',
  status progress_state not null default 'in_progress',
  completed_at timestamptz,
  xp_awarded int not null default 0,
  primary key (user_id, district_id)
);
create index district_progress_status_idx on district_progress(user_id, status);

create table xp_events (                 -- শুধু যোগ হয়, কখনো বদলায় না (অডিটযোগ্য)
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  amount int not null check (amount <> 0),
  reason text not null,
  ref_id uuid,
  created_at timestamptz not null default now()
);
create unique index xp_events_once on xp_events(user_id, reason, ref_id) where ref_id is not null;
create index xp_events_user_time_idx on xp_events(user_id, created_at desc);
create index xp_events_time_idx on xp_events(created_at desc);

create table streaks (
  user_id uuid primary key references auth.users(id) on delete cascade,
  current_days int not null default 0,
  longest_days int not null default 0,
  last_active date
);

create table goals (
  user_id uuid not null references auth.users(id) on delete cascade,
  period goal_period not null,
  target_xp int not null check (target_xp > 0),
  primary key (user_id, period)
);

create table badges (
  id uuid primary key default gen_random_uuid(),
  district_id uuid unique references districts(id) on delete cascade,
  slug text not null unique,
  name_bn text not null, description_bn text,
  icon_url text
);

create table user_badges (
  user_id uuid not null references auth.users(id) on delete cascade,
  badge_id uuid not null references badges(id) on delete cascade,
  earned_at timestamptz not null default now(),
  primary key (user_id, badge_id)
);

create table achievements (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name_bn text not null, description_bn text not null,
  xp_reward int not null default 0 check (xp_reward >= 0),
  rule jsonb not null default '{}'
);

create table user_achievements (
  user_id uuid not null references auth.users(id) on delete cascade,
  achievement_id uuid not null references achievements(id) on delete cascade,
  earned_at timestamptz not null default now(),
  primary key (user_id, achievement_id)
);

create table certificates (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  number text not null unique,
  holder_name text not null,
  issued_at timestamptz not null default now()
);

create table bookmarks (
  user_id uuid not null references auth.users(id) on delete cascade,
  entity_type text not null check (entity_type in ('district','lesson','person','food','heritage_site')),
  entity_id uuid not null,
  created_at timestamptz not null default now(),
  primary key (user_id, entity_type, entity_id)
);

create table notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title_bn text not null, body_bn text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index notifications_user_idx on notifications(user_id, created_at desc);

create table audit_log (
  id bigint generated always as identity primary key,
  actor uuid, table_name text not null, row_id text,
  action text not null, changed_at timestamptz not null default now()
);
