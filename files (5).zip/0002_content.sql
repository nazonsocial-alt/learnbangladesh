-- 0002: ব্যবহারকারী ও কনটেন্ট টেবিল

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'শিক্ষার্থী' check (char_length(display_name) between 1 and 60),
  avatar_url text,
  locale text not null default 'bn' check (locale in ('bn', 'en')),
  audience text check (audience in ('student','job_seeker','teacher','tourist','parent','expat','enthusiast')),
  daily_goal_minutes int not null default 10 check (daily_goal_minutes between 5 and 120),
  show_on_leaderboard boolean not null default true,
  referral_code text not null unique default encode(gen_random_bytes(5), 'hex'),
  referred_by uuid references profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table user_roles (
  user_id uuid not null references auth.users(id) on delete cascade,
  role app_role not null,
  primary key (user_id, role)
);

create table divisions (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name_bn text not null,
  name_en text not null,
  sort_order int not null default 0
);

create table districts (
  id uuid primary key default gen_random_uuid(),
  division_id uuid not null references divisions(id),
  slug text not null unique check (slug ~ '^[a-z0-9-]+$'),
  name_bn text not null,
  name_en text not null,
  status content_status not null default 'draft',
  reviewed_by uuid references auth.users(id),
  published_at timestamptz,
  lat numeric(9,6), lng numeric(9,6),
  map_feature_id text,                    -- GeoJSON ফিচার আইডি
  xp_reward int not null default 100 check (xp_reward >= 0),
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index districts_division_idx on districts(division_id);
create index districts_status_idx on districts(status);

create table district_neighbors (
  district_id uuid not null references districts(id) on delete cascade,
  neighbor_id uuid not null references districts(id) on delete cascade,
  primary key (district_id, neighbor_id),
  check (district_id <> neighbor_id)
);

create table district_sections (
  id uuid primary key default gen_random_uuid(),
  district_id uuid not null references districts(id) on delete cascade,
  kind section_kind not null,
  body_bn text not null,
  body_en text,
  status content_status not null default 'draft',
  updated_at timestamptz not null default now(),
  unique (district_id, kind)
);

create table learning_paths (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  title_bn text not null, title_en text,
  description_bn text, description_en text,
  sort_order int not null default 0,
  status content_status not null default 'draft'
);

create table lessons (
  id uuid primary key default gen_random_uuid(),
  path_id uuid not null references learning_paths(id),
  district_id uuid references districts(id) on delete set null,
  slug text not null unique check (slug ~ '^[a-z0-9-]+$'),
  title_bn text not null, title_en text,
  summary_bn text,
  body_bn text not null, body_en text,
  xp_reward int not null default 20 check (xp_reward >= 0),
  estimated_minutes int not null default 5 check (estimated_minutes > 0),
  sort_order int not null default 0,
  status content_status not null default 'draft',
  reviewed_by uuid references auth.users(id),
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index lessons_path_idx on lessons(path_id, sort_order);
create index lessons_status_idx on lessons(status);

create table people (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name_bn text not null, name_en text,
  bio_bn text not null,
  born_on date, died_on date,
  status content_status not null default 'draft'
);

create table foods (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  district_id uuid references districts(id) on delete set null,
  name_bn text not null, name_en text,
  description_bn text not null,
  status content_status not null default 'draft'
);

create table heritage_sites (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  district_id uuid references districts(id) on delete set null,
  name_bn text not null, name_en text,
  description_bn text not null,
  lat numeric(9,6), lng numeric(9,6),
  status content_status not null default 'draft'
);

create table history_events (            -- "ইতিহাসের এই দিনে"
  id uuid primary key default gen_random_uuid(),
  month int not null check (month between 1 and 12),
  day int not null check (day between 1 and 31),
  year int,
  title_bn text not null, body_bn text not null,
  status content_status not null default 'draft'
);
create index history_events_day_idx on history_events(month, day);

create table sources (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  author text, publisher text,
  url text check (url is null or url ~ '^https?://'),
  accessed_on date,
  license_note text
);

create table content_sources (           -- যেকোনো কনটেন্টের সঙ্গে সূত্র যুক্ত
  id uuid primary key default gen_random_uuid(),
  entity_type text not null check (entity_type in ('district','district_section','lesson','person','food','heritage_site','history_event','question')),
  entity_id uuid not null,
  source_id uuid not null references sources(id) on delete restrict,
  note text,
  unique (entity_type, entity_id, source_id)
);
create index content_sources_entity_idx on content_sources(entity_type, entity_id);

create table media_items (
  id uuid primary key default gen_random_uuid(),
  kind media_kind not null default 'image',
  title text not null, description text,
  source text, author text,
  license media_license, license_url text,
  attribution text,
  category text, district_id uuid references districts(id) on delete set null,
  lesson_id uuid references lessons(id) on delete set null,
  tags text[] not null default '{}',
  url text not null, thumbnail_url text,
  alt_bn text,
  status content_status not null default 'draft',
  uploaded_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  -- লাইসেন্স ও সূত্র ছাড়া মিডিয়া প্রকাশ করা যাবে না
  constraint media_publish_requires_license check (
    status <> 'published'
    or (license is not null and source is not null and alt_bn is not null
        and (license in ('public_domain','cc0','original','user_uploaded') or attribution is not null))
  )
);
create index media_district_idx on media_items(district_id);
create index media_tags_idx on media_items using gin(tags);

create table daily_features (
  feature_date date not null,
  kind daily_kind not null,
  ref_id uuid not null,
  primary key (feature_date, kind)
);
